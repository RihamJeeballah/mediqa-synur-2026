# scripts/postprocess_fp_only.py
import json
from pathlib import Path
from typing import Dict, Any, List
from src.schema import SynurSchema


# =========================
# CONFIG
# =========================
SCHEMA_PATH = "data/synur_schema.json"
DEV_PATH = "data/dev.jsonl"
PRED_PATH = "outputs/preds_dev_precfilter.jsonl"
OUT_PATH = "outputs/preds_dev_precfilter_postprocessed.jsonl"


# =========================
# HELPERS
# =========================
def norm(x):
    return " ".join(str(x).lower().split())


def load_jsonl(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(l) for l in f]


# =========================
# FP-ONLY POSTPROCESS
# =========================
def fix_values_only(
    observations: List[Dict[str, Any]],
    transcript: str,
    schema_by_id: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:

    transcript_l = transcript.lower()
    fixed = []

    for o in observations:
        if not isinstance(o, dict):
            fixed.append(o)
            continue

        cid = str(o.get("id"))
        val = o.get("value")
        s = schema_by_id.get(cid, {})
        vtype = s.get("value_type", "")
        enum = s.get("value_enum", [])

        # ---------------------------------
        # 1) ENUM NORMALIZATION (safe)
        # ---------------------------------
        if vtype in {"SINGLE_SELECT", "MULTI_SELECT"} and enum:
            enum_norm = {norm(e): e for e in enum}

            if vtype == "SINGLE_SELECT" and isinstance(val, str):
                k = norm(val)
                if k in enum_norm:
                    o["value"] = enum_norm[k]

            if vtype == "MULTI_SELECT":
                if not isinstance(val, list):
                    val = [val]

                found = set(norm(v) for v in val if isinstance(v, str))

                # expand using transcript (NO deletions)
                for e in enum:
                    if norm(e) in transcript_l:
                        found.add(norm(e))

                o["value"] = [enum_norm[k] for k in found if k in enum_norm]

        # ---------------------------------
        # 2) NUMERIC NORMALIZATION
        # ---------------------------------
        if vtype == "NUMERIC":
            try:
                o["value"] = float(val) if "." in str(val) else int(val)
            except Exception:
                pass

        # ---------------------------------
        # 3) STRING LIST → STRING (evaluator quirk)
        # ---------------------------------
        if vtype == "STRING" and isinstance(val, list) and len(val) == 1:
            o["value"] = val[0]

        fixed.append(o)

    return fixed


# =========================
# RUN
# =========================
def main():
    schema = SynurSchema(SCHEMA_PATH)
    dev = load_jsonl(DEV_PATH)
    preds = load_jsonl(PRED_PATH)

    dev_map = {
        str(r["id"]): (r.get("transcript") or r.get("text") or "")
        for r in dev
    }

    Path(OUT_PATH).parent.mkdir(parents=True, exist_ok=True)

    with open(OUT_PATH, "w", encoding="utf-8") as fout:
        for rec in preds:
            rid = str(rec.get("id"))
            obs = rec.get("observations", [])
            transcript = dev_map.get(rid, "")

            new_obs = fix_values_only(
                obs,
                transcript,
                schema.by_id
            )

            fout.write(json.dumps({
                "id": rid,
                "observations": new_obs
            }, ensure_ascii=False) + "\n")

    print(f"✅ Saved FP-only optimized predictions to: {OUT_PATH}")


if __name__ == "__main__":
    main()
