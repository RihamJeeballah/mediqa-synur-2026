# src/run.py
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any

from src.schema import SynurSchema
from src.agents.extract import ExtractorAgent
from src.agents.validate import ValidatorAgent
from src.agents.precision_filter import PrecisionFilterAgent


def split_transcript(text: str, max_chars: int = 1400) -> List[str]:
    parts, buf, cur = [], [], 0
    for p in text.split("\n\n"):
        if cur + len(p) > max_chars and buf:
            parts.append("\n\n".join(buf))
            buf, cur = [], 0
        buf.append(p)
        cur += len(p)
    if buf:
        parts.append("\n\n".join(buf))
    return parts


def chunk_schema_ids(ids: List[str], size: int) -> List[List[str]]:
    return [ids[i:i + size] for i in range(0, len(ids), size)]


SUPPRESS_ALWAYS_BY_NAME = {
    "Orientation",
    "Mental status",
    "Memory status",
    "Delirium symptoms",
    "Patient identification",
    "Skin condition",
    "Meal consumption",
    "Voiding function",
    "Pain description",
    "Vaginal discharge",
}

SUPPRESS_NEGATIVE_ONLY_BY_NAME = {
    "Vomiting",
    "Dyspnea",
    "Gas passage",
    "Urinary stone",
}


def has_explicit_negation(evidence: str) -> bool:
    if not isinstance(evidence, str):
        return False
    e = evidence.lower()
    neg_words = ["no ", "denies", "without", "absent", "none", "not "]
    return any(w in e for w in neg_words)


def apply_suppression_table(obs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    cleaned = []
    for o in obs:
        if not isinstance(o, dict):
            continue
        name = o.get("name", "")
        value = o.get("value", None)
        evidence = o.get("evidence", "")

        if name in SUPPRESS_ALWAYS_BY_NAME:
            continue

        if name in SUPPRESS_NEGATIVE_ONLY_BY_NAME:
            if isinstance(value, str) and value.strip().lower() in {"no", "none", "absent"}:
                if not has_explicit_negation(evidence):
                    continue

        cleaned.append(o)

    return cleaned


def process_record(
    record: Dict[str, Any],
    model: str,
    schema: SynurSchema,
    batch_size: int,
    segment: bool,
    use_suppress_table: bool,
    use_precision_filter: bool,
    filter_model: str,
) -> Dict[str, Any]:
    rid = record.get("id")
    text = record.get("transcript") or record.get("text") or ""

    if not isinstance(text, str) or not text.strip():
        return {"id": rid, "observations": []}

    extractor = ExtractorAgent(model, schema.by_id)
    validator = ValidatorAgent(schema.by_id)

    schema_ids = list(schema.by_id.keys())
    schema_batches = chunk_schema_ids(schema_ids, batch_size)
    text_chunks = split_transcript(text) if segment else [text]

    raw: List[Dict[str, Any]] = []
    for t in text_chunks:
        for sb in schema_batches:
            extracted = extractor.run(t, sb)
            if isinstance(extracted, list):
                for item in extracted:
                    if isinstance(item, dict):
                        raw.append(item)

    validated = validator.run(raw, text)

    if use_suppress_table:
        validated = apply_suppression_table(validated)

    if use_precision_filter:
        pf = PrecisionFilterAgent(
            model=filter_model,
            schema_by_id=schema.by_id,
            max_tokens=450,
            temperature=0.0,
        )
        validated = pf.filter_observations(validated, text)

    return {"id": rid, "observations": validated}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="llama3.3")
    ap.add_argument("--data_dir", default="data")
    ap.add_argument("--schema_path", required=True)
    ap.add_argument("--batch_size", type=int, default=25)
    ap.add_argument("--segment", action="store_true")
    ap.add_argument("--suppress_table", action="store_true")
    ap.add_argument("--precision_filter", action="store_true")
    ap.add_argument("--filter_model", default=None)

    args = ap.parse_args()

    schema = SynurSchema(args.schema_path)

    inp = Path(args.data_dir) / f"{args.split}.jsonl"
    out = Path(args.out)

    filter_model = args.filter_model or args.model
    out.parent.mkdir(parents=True, exist_ok=True)

    with inp.open("r", encoding="utf-8") as fin, out.open("w", encoding="utf-8") as fout:
        for line in fin:
            rec = json.loads(line)
            res = process_record(
                record=rec,
                model=args.model,
                schema=schema,
                batch_size=args.batch_size,
                segment=args.segment,
                use_suppress_table=args.suppress_table,
                use_precision_filter=args.precision_filter,
                filter_model=filter_model,
            )
            fout.write(json.dumps(res, ensure_ascii=False) + "\n")

    print(f"✅ Saved to {out}")


if __name__ == "__main__":
    main()
