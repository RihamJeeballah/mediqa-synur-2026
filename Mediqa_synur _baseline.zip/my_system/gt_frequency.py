# gt_frequency.py
import json
from collections import Counter
from pathlib import Path

DEV_PATH = "/home/riham/Desktop/clinical_nlp/mediqa_synur/my_system/data/dev.jsonl"
OUT_PATH = "/home/riham/Desktop/clinical_nlp/mediqa_synur/my_system/outputs/gt_id_frequency.txt"

counter = Counter()
total_records = 0

with open(DEV_PATH, "r", encoding="utf-8") as f:
    for line in f:
        rec = json.loads(line)
        total_records += 1

        obs = rec.get("observations", [])

        # 🔑 FIX: observations can be string or list
        if isinstance(obs, str):
            try:
                obs = json.loads(obs)
            except Exception:
                obs = []

        seen_ids = set()
        for o in obs:
            if isinstance(o, dict) and "id" in o:
                seen_ids.add(str(o["id"]))

        for oid in seen_ids:
            counter[oid] += 1

# sort by frequency
items = sorted(counter.items(), key=lambda x: x[1], reverse=True)

Path(OUT_PATH).parent.mkdir(parents=True, exist_ok=True)

with open(OUT_PATH, "w", encoding="utf-8") as f:
    f.write(f"Total records: {total_records}\n\n")
    f.write("ID\tCOUNT\tPERCENT\n")
    for oid, cnt in items:
        pct = 100.0 * cnt / total_records
        f.write(f"{oid}\t{cnt}\t{pct:.1f}%\n")

print("✅ GT frequency analysis complete")
print(f"📄 Output saved to: {OUT_PATH}")
